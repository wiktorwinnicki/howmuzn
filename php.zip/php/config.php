<?php

$con = mysqli_connect("localhost","root","","user_management") or die("Couldn't connect to database")

?>